<!DOCTYPE html>
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<head>
  <!-- =====  BASIC PAGE NEEDS  ===== -->
  <meta charset="utf-8">
  <title></title>
  <!-- =====  SEO MATE  ===== -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="viewport" content="width=device-width">
  <!-- =====  CSS  ===== -->
  <link href="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
 .list-group
 {
    padding-left:15px;
 }
 
 .list-group li
 {
  padding-bottom:10px;
 }
 p
 {
   font-size:12px;
 }
 
 .list-group li
 {
   font-size:12px;
 }
</style>
</head>
<body class="hm-gradient">    
    <main>
        
        <!--MDB -->
        <div class="container mt-4">

            <div class="text-center darken-grey-text mb-4">
                <h6 class=" mt-4 mb-3 ">How Atzcart.com Protect your orders?</p>
            </div>
            <p>Before ordering, you can click the 'send Inquiry' or 'Chat Now' buttons to communicate with the supplier and confirm product details.</p>
   

            <!--Jumbotron-->
            <div class="jumbotron">
				<ul class="list-group list-group-flush">
					<ul class="list-group">
					    <li>
						Before ordering, you can click the 'send Inquiry' or 'Chat Now' buttons to communicate </li>
						
						 <li>
						Before ordering, you can click the 'send Inquiry' or 'Chat Now' buttons to communicate </li>
						 <li>
						Before ordering, you can click the 'send Inquiry' or 'Chat Now' buttons to communicate</li>
						
						 <li>
						Before ordering, you can click the 'send Inquiry' or 'Chat Now' buttons to communicate </li>
					</ul>
				</ul>	    
            <!--Jumbotron-->          
        
        </div>
        <!--MDB -->
		  <div class="text-center darken-grey-text mb-4">
                <h6 class=" mt-4 mb-3 ">So how can I use Trade Assurance</p>
				 <li>Trade Assurance service is free to buyers.</li>      
			   <img src="images/screen.jpg" class="img-fluid">
            </div>
      
    </main>
</body>

</html>




