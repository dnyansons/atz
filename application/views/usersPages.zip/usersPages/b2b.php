<!DOCTYPE html>
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<head>
  <!-- =====  BASIC PAGE NEEDS  ===== -->
  <meta charset="utf-8">
  <title>OYEENok E-commerce Bootstrap Template</title>
  <!-- =====  SEO MATE  ===== -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="distribution" content="global">
  <meta name="revisit-after" content="2 Days">
  <meta name="robots" content="ALL">
  <meta name="rating" content="8 YEARS">
  <meta name="Language" content="en-us">
  <meta name="GOOGLEBOT" content="NOARCHIVE">
  <!-- =====  MOBILE SPECIFICATION  ===== -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="viewport" content="width=device-width">
  <!-- =====  CSS  ===== -->
  <link href="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
 .list-group
 {
    padding-left:15px;
 }
 
 .list-group li
 {
  padding-bottom:10px;
 }
</style>
</head>
<body class="hm-gradient">    
    <main>
         <!--MDB -->
        <div class="container mt-4">
            <!--Jumbotron-->

            <!--News card-->
            <div class=" mb-4  hoverable">
                <div class="">
                    <!--Grid row-->
                    <div class="row">

                        <!--Grid column-->
                        <div class="col-md-4 offset-md-1">
                          <h6 class="card-title font-bold pb-2">Unlocking Opportunity for SMEs</h6>
                            <!--Featured image-->
                            <div class="view overlay hm-white-slight">
                                <img src="https://mdbootstrap.com/img/Photos/Others/laptop-sm.jpg" class="img-fluid" alt="Sample image for first version of blog listing">
                                <a>
                                    <div class="mask"></div>
                                </a>
                            </div>
                        </div>
                        <!--Grid column-->

                        <!--Grid column-->
                        <div class="col-md-7 text-left  mt-3">
                            <!--Excerpt-->
                            <a href="" class="green-text">
                                <h6 class="font-bold pb-1"><i class="fa fa-desktop"></i> Executive Summary</h6>
                            </a>
                            <h6 class="mb-4"><strong>This is title of the news</strong></h6>
							<ul class="list-group list-group-flush">
							 <ul class="list-group">
							    <li>
								Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, totam
                                rem aperiam, eaque ipsa quae ab 
								</li>
								 <li>
								Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, totam
                                rem aperiam, eaque ipsa quae ab illo inventore veritatis et
								</li>
								
								
								 <li>
								Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, totam
                                rem aperiam, eaque ipsa quae ab illo </li>
								
								
								 <li>
								Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, totam
                                rem aperiam, 
								</li>
								
								
								 <li>
								Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, totam
                                rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi arch
								</li>
								 <li>
								Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, totam
                                rem aperiam, 
								</li>
							  </ul>
							</ul>
                        </div>
                        <!--Grid column-->
                    </div>
                    <!--Grid row-->
                </div>
            </div>
            <!--News card-->
        

        </div>
        <!--MDB -->
      
    </main>
  

</body>

</html>




